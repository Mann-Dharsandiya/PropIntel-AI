 import { UserModel, IUser } from "../models/User.model";
import {
  RegisterInput,
  LoginInput,
  AuthResponse,
  JwtPayload,
} from "../types/auth.types";

import { generateTokens } from "./token.service";
import { sendPasswordResetEmail } from "./email.service";
import { ApiError } from "../utils/ApiError";

import crypto from "crypto";

/**
 * Register User
 */
export async function registerUser(
  input: RegisterInput,
): Promise<AuthResponse> {
  const existingUser = await UserModel.findOne({
    email: input.email.toLowerCase(),
  });

  if (existingUser) {
    throw ApiError.badRequest("Email already exists");
  }

  const user = await UserModel.create({
    name: input.name,
    email: input.email.toLowerCase(),
    phone: input.phone,
    password: input.password,
    role: input.role ?? "buyer",
  });

  const payload: JwtPayload = {
    _id: user.id,
    sub: user.id,
    email: user.email,
    role: user.role,
  };

  const tokens = generateTokens(payload);

  return {
    user,
    tokens,
  };
}

/**
 * Login User
 */
export async function loginUser(
  input: LoginInput,
): Promise<AuthResponse> {
  const user = await UserModel.findOne({
    email: input.email.toLowerCase(),
  }).select("+password");

  if (!user) {
    throw ApiError.unauthorized(
      "Invalid email or password",
    );
  }

  const isMatch = await user.comparePassword(
    input.password,
  );

  if (!isMatch) {
    throw ApiError.unauthorized(
      "Invalid email or password",
    );
  }

  const payload: JwtPayload = {
    _id: user.id,
    sub: user.id,
    email: user.email,
    role: user.role,
  };

  const tokens = generateTokens(payload);

  return {
    user,
    tokens,
  };
}

/**
 * Get User
 */
export async function getUserById(
  id: string,
): Promise<IUser> {
  const user = await UserModel.findById(id);

  if (!user) {
    throw ApiError.notFound("User not found");
  }

  return user;
}

/**
 * Generate Password Reset Token
 */
function generateResetToken() {
  const token = crypto
    .randomBytes(32)
    .toString("hex");

  const hashedToken = crypto
    .createHash("sha256")
    .update(token)
    .digest("hex");

  return {
    token,
    hashedToken,
  };
}

/**
 * Forgot Password
 */
export async function forgotPassword(
  email: string,
) {
  const user = await UserModel.findOne({
    email: email.toLowerCase(),
  });

  if (!user) {
    throw ApiError.notFound(
      "No account found with this email.",
    );
  }

  const { token, hashedToken } =
    generateResetToken();

  user.passwordResetToken = hashedToken;

  user.passwordResetExpires = new Date(
    Date.now() + 15 * 60 * 1000,
  );

  await user.save();

  const resetUrl = `${process.env.CLIENT_ORIGIN}/reset-password/${token}`;

  await sendPasswordResetEmail(
    user.email,
    user.name,
    resetUrl,
  );

  return {
    success: true,
    message:
      "Password reset email sent successfully.",
  };
}
/**
 * Reset Password
 */
export async function resetPassword(
  token: string,
  newPassword: string,
) {
  const hashedToken = crypto
    .createHash("sha256")
    .update(token)
    .digest("hex");

  const user = await UserModel.findOne({
    passwordResetToken: hashedToken,
    passwordResetExpires: {
      $gt: new Date(),
    },
  }).select("+password");

  if (!user) {
    throw ApiError.badRequest(
      "Reset token is invalid or has expired."
    );
  }

  user.password = newPassword;

  user.passwordResetToken = undefined;
  user.passwordResetExpires = undefined;

  await user.save();

  return {
    success: true,
    message: "Password reset successful.",
  };
}