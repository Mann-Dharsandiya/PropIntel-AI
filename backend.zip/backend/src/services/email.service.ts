 import nodemailer from "nodemailer";

let transporter: nodemailer.Transporter | null = null;

async function getTransporter() {
  if (transporter) return transporter;

  console.log("Creating Ethereal account...");

  const testAccount = await nodemailer.createTestAccount();

  console.log("====================================");
  console.log("ETHEREAL ACCOUNT");
  console.log(testAccount);
  console.log("====================================");

  transporter = nodemailer.createTransport({
    host: testAccount.smtp.host,
    port: testAccount.smtp.port,
    secure: testAccount.smtp.secure,
    auth: {
      user: testAccount.user,
      pass: testAccount.pass,
    },
  });

  return transporter;
}

export async function sendPasswordResetEmail(
  email: string,
  name: string,
  resetUrl: string,
) {
  try {
    const mailer = await getTransporter();

    const info = await mailer.sendMail({
      from: '"PropIntel-AI" <no-reply@propintel.ai>',
      to: email,
      subject: "Reset Password",
      html: `
        <h2>Hello ${name}</h2>
        <p>Click below to reset your password.</p>

        <a href="${resetUrl}">
            Reset Password
        </a>
      `,
    });

    console.log("====================================");
    console.log("MESSAGE ID:");
    console.log(info.messageId);

    console.log("PREVIEW URL:");
    console.log(nodemailer.getTestMessageUrl(info));

    console.log("====================================");
  } catch (err) {
    console.error("EMAIL ERROR");
    console.error(err);
    throw err;
  }
}