 import "express-serve-static-core";
import type { JwtPayload } from "./auth.types";

declare module "express-serve-static-core" {
  interface Request {
    user?: JwtPayload;
  }
}

export {};