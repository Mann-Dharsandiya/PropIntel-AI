 import { Router } from "express";

import {
  register,
  login,
  logout,
  me,
  refreshToken,
  forgotPasswordController,
  resetPasswordController,
} from "../controllers/auth.controller";

import { authenticate } from "../middlewares/authenticate";
import { validate } from "../middlewares/validate";

import {
  registerValidator,
  loginValidator,
  forgotPasswordValidator,
  resetPasswordValidator,
} from "../middlewares/authValidators";

const router = Router();

/**
 * ============================================
 * Public Routes
 * ============================================
 */

// Register
router.post(
  "/register",
  registerValidator,
  validate,
  register,
);

// Login
router.post(
  "/login",
  loginValidator,
  validate,
  login,
);

// Forgot Password
router.post(
  "/forgot-password",
  forgotPasswordValidator,
  validate,
  forgotPasswordController,
);

// Reset Password
router.post(
  "/reset-password/:token",
  resetPasswordValidator,
  validate,
  resetPasswordController,
);

// Refresh Access Token
router.post(
  "/refresh-token",
  refreshToken,
);

// Logout
router.post(
  "/logout",
  logout,
);

/**
 * ============================================
 * Protected Routes
 * ============================================
 */

// Current Logged-in User
router.get(
  "/me",
  authenticate,
  me,
);

export default router;