 import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { Toaster } from "react-hot-toast";

import {
  QueryClient,
  QueryClientProvider,
} from "@tanstack/react-query";

import { AuthProvider } from "@/context/AuthContext";

import App from "./App";
import "./index.css";

const queryClient = new QueryClient();

ReactDOM.createRoot(
  document.getElementById("root")!
).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>

        <AuthProvider>

          <Toaster
            position="top-right"
            reverseOrder={false}
          />

          <App />

        </AuthProvider>

      </BrowserRouter>
    </QueryClientProvider>
  </React.StrictMode>
);